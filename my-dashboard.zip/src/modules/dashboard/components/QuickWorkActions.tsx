import { ChevronDown, Clock3, Plus, Save, SlidersHorizontal, Target } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';

import type {
  WorkDay,
  WorkSession,
  WorkWeek,
  WorkWeekGoals,
} from '@/modules/work/types/work.types';
import {
  formatGoalValue,
  getDefaultWorkSessionTimes,
  synchronizeWorkGoals,
  type WorkGoalSource,
} from '@/modules/work/utils/workCalculations';

type QuickWorkActionsProps = {
  day: WorkDay;
  week: WorkWeek;
  isSaving: boolean;
  onUpdateDay: (updatedDay: WorkDay) => Promise<void>;
  onUpdateGoals: (goals: WorkWeekGoals) => Promise<void>;
};

const inputClasses =
  'h-9 w-full rounded-lg border border-zinc-700 bg-zinc-950 px-2.5 text-sm font-medium text-zinc-100 outline-none transition placeholder:text-zinc-600 focus:border-[var(--app-accent)] focus:ring-1 focus:ring-[var(--app-accent)]';

const labelClasses =
  'mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.12em] text-zinc-500';

const buttonClasses =
  'flex h-9 items-center justify-center gap-2 rounded-lg border border-[var(--app-accent-border)] bg-[var(--app-accent-soft)] px-3 text-xs font-semibold text-[var(--app-accent)] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50';

const panelToggleClasses =
  'flex min-h-11 w-full items-center justify-between gap-3 rounded-xl border border-zinc-700 bg-zinc-950/45 px-4 py-3 text-left transition hover:border-zinc-600 hover:bg-zinc-950/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--app-accent)]';

function parseNonNegativeInteger(value: string): number {
  const parsedValue = Number.parseInt(value, 10);

  if (!Number.isFinite(parsedValue) || parsedValue < 0) {
    return 0;
  }

  return parsedValue;
}

function parseNullableNumber(value: string): number | null {
  if (value.trim() === '') {
    return null;
  }

  const parsedValue = Number.parseFloat(value.replace(',', '.'));

  if (!Number.isFinite(parsedValue) || parsedValue < 0) {
    return null;
  }

  return parsedValue;
}

function parseWorkRating(value: string): number | null {
  const parsedValue = parseNullableNumber(value);

  if (parsedValue === null) {
    return null;
  }

  return Math.round(Math.min(10, parsedValue) * 10) / 10;
}

export default function QuickWorkActions({
  day,
  week,
  isSaving,
  onUpdateDay,
  onUpdateGoals,
}: QuickWorkActionsProps) {
  const [isQuickEntryOpen, setIsQuickEntryOpen] = useState(false);

  const [areGoalsOpen, setAreGoalsOpen] = useState(false);

  const [messages, setMessages] = useState(String(day.messages));

  const [heldMessages, setHeldMessages] = useState(String(day.heldMessages));

  const [workRating, setWorkRating] = useState(
    day.workRating === null ? '' : String(day.workRating)
  );

  const [beers, setBeers] = useState(String(day.beers));

  const [initialSessionTimes] = useState(() => getDefaultWorkSessionTimes());

  const [sessionStart, setSessionStart] = useState(initialSessionTimes.startTime);

  const [sessionEnd, setSessionEnd] = useState(initialSessionTimes.endTime);

  const [dailyMessagesTarget, setDailyMessagesTarget] = useState(
    formatGoalValue(week.goals.dailyMessagesTarget)
  );

  const [weeklyMessagesTarget, setWeeklyMessagesTarget] = useState(
    formatGoalValue(week.goals.weeklyMessagesTarget)
  );

  const [weeklyMessagesTarget5Days, setWeeklyMessagesTarget5Days] = useState(
    formatGoalValue(week.goals.weeklyMessagesTarget5Days)
  );

  const [dailyHoursTarget, setDailyHoursTarget] = useState(
    formatGoalValue(week.goals.dailyHoursTarget)
  );

  const [lastGoalSource, setLastGoalSource] = useState<WorkGoalSource>('weekly-7-days');

  useEffect(() => {
    setMessages(String(day.messages));

    setHeldMessages(String(day.heldMessages));

    setWorkRating(day.workRating === null ? '' : String(day.workRating));

    setBeers(String(day.beers));
  }, [day.id, day.messages, day.heldMessages, day.workRating, day.beers]);

  useEffect(() => {
    setDailyMessagesTarget(formatGoalValue(week.goals.dailyMessagesTarget));

    setWeeklyMessagesTarget(formatGoalValue(week.goals.weeklyMessagesTarget));

    setWeeklyMessagesTarget5Days(formatGoalValue(week.goals.weeklyMessagesTarget5Days));

    setDailyHoursTarget(formatGoalValue(week.goals.dailyHoursTarget));
  }, [
    week.goals.dailyHoursTarget,
    week.goals.dailyMessagesTarget,
    week.goals.weeklyMessagesTarget,
    week.goals.weeklyMessagesTarget5Days,
  ]);

  function synchronizeGoalFields(source: WorkGoalSource, value: string) {
    const sourceValue = parseNullableNumber(value);

    const synchronizedGoals = synchronizeWorkGoals(
      source,
      sourceValue,
      parseNullableNumber(dailyHoursTarget)
    );

    setDailyMessagesTarget(formatGoalValue(synchronizedGoals.dailyMessagesTarget));

    setWeeklyMessagesTarget(formatGoalValue(synchronizedGoals.weeklyMessagesTarget));

    setWeeklyMessagesTarget5Days(formatGoalValue(synchronizedGoals.weeklyMessagesTarget5Days));

    setLastGoalSource(source);
  }

  async function handleDaySubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    await onUpdateDay({
      ...day,
      messages: parseNonNegativeInteger(messages),
      heldMessages: parseNonNegativeInteger(heldMessages),
      workRating: parseWorkRating(workRating),
      beers: parseNonNegativeInteger(beers),
    });
  }

  function refreshSessionTimes() {
    const { startTime, endTime } = getDefaultWorkSessionTimes();

    setSessionStart(startTime);
    setSessionEnd(endTime);
  }

  async function handleSessionSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const newSession: WorkSession = {
      id: crypto.randomUUID(),
      startTime: sessionStart,
      endTime: sessionEnd,
    };

    await onUpdateDay({
      ...day,
      sessions: [...day.sessions, newSession],
    });

    refreshSessionTimes();
  }

  async function handleGoalsSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const sourceValue =
      lastGoalSource === 'daily'
        ? parseNullableNumber(dailyMessagesTarget)
        : lastGoalSource === 'weekly-7-days'
          ? parseNullableNumber(weeklyMessagesTarget)
          : parseNullableNumber(weeklyMessagesTarget5Days);

    const synchronizedGoals = synchronizeWorkGoals(
      lastGoalSource,
      sourceValue,
      parseNullableNumber(dailyHoursTarget)
    );

    await onUpdateGoals(synchronizedGoals);
  }

  return (
    <section className="rounded-xl border border-zinc-700 bg-zinc-900/65 shadow-sm">
      <div className="border-b border-zinc-700 px-4 py-3">
        <h2 className="text-sm font-semibold text-zinc-100">Sterowanie Dashboardem</h2>

        <p className="mt-0.5 text-xs text-zinc-500">
          Rozwiń tylko panel, którego aktualnie potrzebujesz
        </p>
      </div>

      <div className="space-y-2 p-3">
        <button
          type="button"
          aria-expanded={isQuickEntryOpen}
          aria-controls="dashboard-quick-entry-panel"
          onClick={() => {
            const nextValue = !isQuickEntryOpen;

            setIsQuickEntryOpen(nextValue);

            if (nextValue) {
              refreshSessionTimes();
            }
          }}
          className={panelToggleClasses}
        >
          <span className="flex min-w-0 items-center gap-3">
            <span className="flex size-8 shrink-0 items-center justify-center rounded-lg border border-[var(--app-accent-border)] bg-[var(--app-accent-soft)] text-[var(--app-accent)]">
              <Plus aria-hidden="true" className="size-4" />
            </span>

            <span className="min-w-0">
              <span className="block text-sm font-semibold text-zinc-200">Szybki wpis</span>

              <span className="mt-0.5 block truncate text-[11px] text-zinc-500">
                Dzisiejsze wyniki i nowy blok pracy
              </span>
            </span>
          </span>

          <ChevronDown
            aria-hidden="true"
            className={`size-4 shrink-0 text-zinc-500 transition-transform ${
              isQuickEntryOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {isQuickEntryOpen && (
          <div
            id="dashboard-quick-entry-panel"
            className="grid gap-3 rounded-xl border border-zinc-700 bg-zinc-950/25 p-3 lg:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2"
          >
            <form
              onSubmit={(event) => {
                void handleDaySubmit(event);
              }}
              className="rounded-xl border border-zinc-700 bg-zinc-950/55 p-3"
            >
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-xs font-semibold text-zinc-300">Dzisiejsze dane</h3>

                <Save aria-hidden="true" className="size-4 text-zinc-500" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label>
                  <span className={labelClasses}>Płatne</span>

                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={messages}
                    onChange={(event) => setMessages(event.target.value)}
                    className={inputClasses}
                  />
                </label>

                <label>
                  <span className={labelClasses}>Zatrzymane</span>

                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={heldMessages}
                    onChange={(event) => setHeldMessages(event.target.value)}
                    className={inputClasses}
                  />
                </label>

                <label>
                  <span className={labelClasses}>Ocena</span>

                  <input
                    type="number"
                    min="0"
                    max="10"
                    step="0.1"
                    value={workRating}
                    onChange={(event) => setWorkRating(event.target.value)}
                    className={inputClasses}
                  />
                </label>

                <label>
                  <span className={labelClasses}>Piwa</span>

                  <input
                    type="number"
                    min="0"
                    step="1"
                    value={beers}
                    onChange={(event) => setBeers(event.target.value)}
                    className={inputClasses}
                  />
                </label>
              </div>

              <button type="submit" disabled={isSaving} className={`${buttonClasses} mt-3 w-full`}>
                <Save aria-hidden="true" className="size-3.5" />
                Zapisz dzień
              </button>
            </form>

            <form
              onSubmit={(event) => {
                void handleSessionSubmit(event);
              }}
              className="rounded-xl border border-zinc-700 bg-zinc-950/55 p-3"
            >
              <div className="mb-3 flex items-center justify-between">
                <h3 className="text-xs font-semibold text-zinc-300">Nowy blok pracy</h3>

                <Clock3 aria-hidden="true" className="size-4 text-zinc-500" />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <label>
                  <span className={labelClasses}>Początek</span>

                  <input
                    type="time"
                    value={sessionStart}
                    onChange={(event) => setSessionStart(event.target.value)}
                    className={inputClasses}
                  />
                </label>

                <label>
                  <span className={labelClasses}>Koniec</span>

                  <input
                    type="time"
                    value={sessionEnd}
                    onChange={(event) => setSessionEnd(event.target.value)}
                    className={inputClasses}
                  />
                </label>
              </div>

              <button type="submit" disabled={isSaving} className={`${buttonClasses} mt-3 w-full`}>
                <Clock3 aria-hidden="true" className="size-3.5" />
                Dodaj blok
              </button>
            </form>
          </div>
        )}

        <button
          type="button"
          aria-expanded={areGoalsOpen}
          aria-controls="dashboard-work-goals-panel"
          onClick={() => setAreGoalsOpen((currentValue) => !currentValue)}
          className={panelToggleClasses}
        >
          <span className="flex min-w-0 items-center gap-3">
            <span className="flex size-8 shrink-0 items-center justify-center rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-500">
              <Target aria-hidden="true" className="size-4" />
            </span>

            <span className="min-w-0">
              <span className="block text-sm font-semibold text-zinc-200">Cele pracy</span>

              <span className="mt-0.5 block truncate text-[11px] text-zinc-500">
                Dzienny, 5 dni, 7 dni i godziny
              </span>
            </span>
          </span>

          <ChevronDown
            aria-hidden="true"
            className={`size-4 shrink-0 text-zinc-500 transition-transform ${
              areGoalsOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {areGoalsOpen && (
          <form
            id="dashboard-work-goals-panel"
            onSubmit={(event) => {
              void handleGoalsSubmit(event);
            }}
            className="rounded-xl border border-zinc-700 bg-zinc-950/55 p-3"
          >
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <h3 className="text-xs font-semibold text-zinc-300">Cele pracy</h3>

                <p className="mt-0.5 text-[10px] text-zinc-500">
                  Zmiana jednego celu przelicza dwa pozostałe
                </p>
              </div>

              <SlidersHorizontal aria-hidden="true" className="size-4 text-zinc-500" />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <label>
                <span className={labelClasses}>Dzienny</span>

                <input
                  type="text"
                  inputMode="decimal"
                  value={dailyMessagesTarget}
                  placeholder="—"
                  onChange={(event) => {
                    const value = event.target.value;

                    setDailyMessagesTarget(value);

                    synchronizeGoalFields('daily', value);
                  }}
                  className={inputClasses}
                />
              </label>

              <label>
                <span className={labelClasses}>Tydzień 7 dni</span>

                <input
                  type="text"
                  inputMode="decimal"
                  value={weeklyMessagesTarget}
                  placeholder="—"
                  onChange={(event) => {
                    const value = event.target.value;

                    setWeeklyMessagesTarget(value);

                    synchronizeGoalFields('weekly-7-days', value);
                  }}
                  className={inputClasses}
                />
              </label>

              <label>
                <span className={labelClasses}>Tydzień 5 dni</span>

                <input
                  type="text"
                  inputMode="decimal"
                  value={weeklyMessagesTarget5Days}
                  placeholder="—"
                  onChange={(event) => {
                    const value = event.target.value;

                    setWeeklyMessagesTarget5Days(value);

                    synchronizeGoalFields('weekly-5-days', value);
                  }}
                  className={inputClasses}
                />
              </label>

              <label>
                <span className={labelClasses}>Godziny dziennie</span>

                <input
                  type="text"
                  inputMode="decimal"
                  value={dailyHoursTarget}
                  placeholder="—"
                  onChange={(event) => setDailyHoursTarget(event.target.value)}
                  className={inputClasses}
                />
              </label>
            </div>

            <button type="submit" disabled={isSaving} className={`${buttonClasses} mt-3 w-full`}>
              <Target aria-hidden="true" className="size-3.5" />
              Zapisz cele
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
